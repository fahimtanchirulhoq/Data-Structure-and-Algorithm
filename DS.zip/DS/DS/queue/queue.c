// #include<stdio.h>
// int main(){
//     int x;
//     scanf("%d",&x);       // format specifier %d of x , &x memory allocation
//     printf(" %d", x);      // format specifier %d what format I will print
//                           //  x define what value i will print

// }
#include <stdio.h>

void enqueue(Queue *q, int item)
{
    if ((q->tail + 1) % (Q_size + 1) == q->head)
    {
        printf("Queue is full");
    }
    q->data[q->tail] = item;
    q->tail = (q->tail + 1) % (Q_size + 1);
}
int dequeue(Queue *q)
{
    int item;
    if (q->tail = q->head)
    {
        printf(" Queue is empty");
        return 1;
    }
    item = q->data[q->data];
    q->head = (q->head) % (Q_size + 1);
    return item;
}
int main()
{

#define Q_size 5
    typedef struct
    {
        int data[Q_size + 1];
        int head, tail;
    } Queue;

    Queue q;
    q.head = 0;
    q.tail = 0;

    // Enqueue some items
    enqueue(&q, 10);
    enqueue(&q, 20);
    enqueue(&q, 30);
    enqueue(&q, 40);
    enqueue(&q, 50);

    // Attempt to enqueue into a full queue
    enqueue(&q, 60);

    // Dequeue and print items
    printf("Dequeued: %d\n", dequeue(&q));
    printf("Dequeued: %d\n", dequeue(&q));
    printf("Dequeued: %d\n", dequeue(&q));
    printf("Dequeued: %d\n", dequeue(&q));
    printf("Dequeued: %d\n", dequeue(&q));

    // Attempt to dequeue from an empty queue
    printf("Dequeued: %d\n", dequeue(&q));

    return 0;
}
