// insertiong at begining
// insterting at tail ( last of list)
// inserting ta middle ( any position)