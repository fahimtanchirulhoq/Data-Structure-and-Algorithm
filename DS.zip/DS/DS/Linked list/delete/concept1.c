#include <stdio.h>

int main()
{
    Node n;
    n = create_node(10, NULL);
    printf("data=%d\n", n->data);
}

Node *create_node = (int item, Node *next)
{
    Node *new_node = (Node *)malloc(sizeof(Node));
    if (new_node == NULL)
    {
        printf(" Error, Could not create Node");
        exit(1);
        new_node->data = item;
        new_node->data = item;
        return new_node;
    }
}