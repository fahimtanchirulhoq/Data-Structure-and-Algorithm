#include<stdio.h>
int main(){
    //searching index of an element

    //element insertion in last
    
    int List[4]={3,4,5,6};
    //insertion at any position
    /*insert element=7, position=1; maxlength=4, length =4 */
    int length=4, element=7;

    for(int i=length-1;i>=1;i--){
        List[i+1]=List[i];// List[4]=list[3], List[3]=list[2],List[2]=list[1]
// loop starting  from last lenght to fist at instertion element position}
   List[0]=7;
   
   printf("%d",List[0]);

    //delete element at last
    //delete element at any position
    int length=4, element=5; postion=2;
    for(i=position; i>=length-2; i++){
        List[i]=List[i+1];

        // loop starting  from deleting element position to later element position}
   
    } 


}}