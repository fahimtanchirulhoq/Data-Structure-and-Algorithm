#include <stdio.h>
#include <stdlib.h>

#define STACK_MAX 100

typedef struct {
    int top;
    int data[STACK_MAX];
} Stack;

void push(Stack *s, int item) {
    if (s->top < STACK_MAX) {
        s->data[s->top] = item;
        s->top++;
    } else {
        printf("Stack is full\n");
    }
}

int pop(Stack *s) {
    int item;
    if (s->top == 0) {
        printf("Stack is empty\n");
        return -1; // Return an error value
    } else {
        s->top--;
        item = s->data[s->top];
        return item;
    }
}

int main() {
    Stack s;
    s.top = 0;

    // Test push
    for (int i = 0; i < 5; i++) { // Try to push 105 elements
        printf("Pushing %d onto stack.\n", i);
        push(&s, i); // i is item
    }

    // Test pop
    for (int i = 0; i < 5; i++) { // Try to pop 105 elements
        int item = pop(&s);
        if (item != -1) {
            printf("Popped %d from stack.\n", item);
        }
    }

    return 0;
}

