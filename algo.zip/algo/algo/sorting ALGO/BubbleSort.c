#include<stdio.h>
int main(){
    int i,n, j, temp;

     printf(" Enter the number of n:");
    scanf("%d",&n);
      int A[n];
    for(i=0;i<n;i++){
        scanf("%d",&A[i]); 
    }
    for( i = 0; i < n; i++){
        for( j=0; j<n-1-i; j++)
        { 
            if(A[i]>A[j+1]){
                temp= A[j];
                A[j]=A[j+1];
            }
    
    }
     }
   
     for(i=0; i<n; i++){
        printf("%d" ,A[i]);
    }

  
    
}