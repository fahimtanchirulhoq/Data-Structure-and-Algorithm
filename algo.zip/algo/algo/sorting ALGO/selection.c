#include<stdio.h>
int main (){
    int i,j,n,index_min;
    printf(" Enter the number of n:");
    scanf("%d",&n);
      int arr[n];
    for(i=0;i<n;i++){
        scanf("%d",&arr[i]); 
    }
  
    for(i=0; i<n-1;i++){
        index_min=i;
for(j=i+1; j<n;j++){
    if(arr[j]<arr[index_min]){
        index_min=j;
    }
}

if(index_min!=i){
    int temp =arr[i];
    arr[i]= arr[index_min];
    arr[index_min]=temp;

}
    }

    for(i=0; i<n; i++){
        printf("%d" ,arr[i]);
    }

}