#include<stdio.h>
int main (){
    int i,j,n,item;
    printf(" Enter the number of n:");
    scanf("%d",&n);
      int A[n];
    for(i=0;i<n;i++){
        scanf("%d",&A[i]); 
    }
  
for(i=1; i<n; i++){
    item=A[i];
    j=i-1;
    while(j>=0 && A[i]>item){
        A[i]=A[j];
        j--;

    }
    A[j]=item;

}

    for(i=0; i<n; i++){
        printf("%d" ,A[i]);
    }

}