#include<stdio.h>
int main (){
    int i,j,n,x;
    printf(" Enter the number of n:");
    scanf("%d",&n);
      int A[n];
    for(i=0;i<n;i++){
        scanf("%d",&A[i]); 
    }
    printf(" Enter x:");
    scanf("%d",&x);
   int  binary_search(int A[], int n, int x);

}

int binary_search(int Arr[], int n, int x){
    int left, right, mid;
    left=0;
    right=n-1;
    while(left<=right){
        mid=(left+right)/2;
        if(Arr[mid]==x){
            return mid;
            printf("Found %d,position is %d ", x,mid);

        }
        if(Arr[mid]<x){
            left=mid+1;
        }
        else{
            right=mid-1;
        }
    }

}