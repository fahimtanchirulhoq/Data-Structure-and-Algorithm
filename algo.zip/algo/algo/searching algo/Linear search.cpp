#include <bits/stdc++.h>
using namespace std;

int x, n;

int main() {
    cout << "Enter number of element for storing data: ";
    cin >> n;

    int linear[n];  // Note: VLA is not standard in C++, but will work on some compilers like GCC
    for (int i = 0; i < n; i++) {
        cin >> linear[i];
    }

    cout << "Searching element: ";
    cin >> x;

    for (int i = 0; i < n; i++) {
        if (linear[i] == x) {
            cout << "Found element: " << x << " and index is " << i << endl;
        }
    }

    return 0;
}