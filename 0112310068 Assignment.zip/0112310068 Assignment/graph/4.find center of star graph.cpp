#include<bits/stdc++.h>
using namespace std;

int inDegree[1005], outDegree[1005];

int findJudge(int n, int trust[][2], int trust_len) {
    for(int i = 0; i < trust_len; i++) {
        int a = trust[i][0];
        int b = trust[i][1];
        outDegree[a]++;
        inDegree[b]++;
    }

    for(int i = 1; i <= n; i++) {
        if(inDegree[i] == n - 1 && outDegree[i] == 0) {
            return i;
        }
    }
    return -1;
}

int main() {
    int n, m;
    cin >> n >> m;
    int trust[10005][2];

    for(int i = 0; i < m; i++) {
        cin >> trust[i][0] >> trust[i][1];
    }

    int judge = findJudge(n, trust, m);
    cout << judge << endl;

    return 0;
}
