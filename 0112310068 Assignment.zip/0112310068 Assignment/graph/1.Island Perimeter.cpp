#include<bits/stdc++.h>
using namespace std;

int grid[110][110];
int row, col;

int islandPerimeter(){
    int perimeter =0;
    for(int i=0;i<row;i++){
        for(int j=0;j<col;j++){
            if(grid[i][j]==1){
                perimeter+=4;
                if(i>0 && grid[i-1][j]==1) perimeter-=2;
                if(j>0 && grid[i][j-1]==1) perimeter-=2;
            }
        }
    }
    return perimeter;
}

int main(){
    cin>>row>>col;
    for(int i=0;i<row;i++){
        for(int j=0;j<col;j++){
            cin>>grid[i][j];
        }
    }

    cout<<islandPerimeter()<<endl;
    return 0;
}
