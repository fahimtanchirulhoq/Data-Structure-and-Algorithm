#include<bits/stdc++.h>
using namespace std;

struct Node {
    int v;
    Node *next;
};

Node *head[100005]; // Adjacency list
int visited[100005];

bool DFS(int u, int destination) {
    if (u == destination) return true;
    visited[u] = 1;

    Node *ptr = head[u];
    while (ptr) {
        if (!visited[ptr->v]) {
            if (DFS(ptr->v, destination)) return true;
        }
        ptr = ptr->next;
    }
    return false;
}

int main() {
    int n, m;
    cin >> n >> m;

    // Reading m edges
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;

        Node *node1 = new Node;
        node1->v = v;
        node1->next = head[u];
        head[u] = node1;

        Node *node2 = new Node;
        node2->v = u;
        node2->next = head[v];
        head[v] = node2;
    }

    int source, destination;
    cin >> source >> destination;

    if (DFS(source, destination)) {
        cout << "true" << endl;
    } else {
        cout << "false" << endl;
    }

    return 0;
}
