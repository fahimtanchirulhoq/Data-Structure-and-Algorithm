#include<bits/stdc++.h>
using namespace std;

int V;
int isConnected[210][210];
int visited[210];

void DFS(int u){
    visited[u]=1;
    for(int v=0;v<V;v++){
        if(isConnected[u][v]==1 && !visited[v]){
            DFS(v);
        }
    }
}

int findProvinces(){
    int count=0;
    for(int i=0;i<V;i++){
        if(!visited[i]){
            DFS(i);
            count++;
        }
    }
    return count;
}

int main(){
    cin>>V;
    for(int i=0;i<V;i++){
        for(int j=0;j<V;j++){
            cin>>isConnected[i][j];
        }
    }

    cout<<findProvinces()<<endl;

    return 0;
}
