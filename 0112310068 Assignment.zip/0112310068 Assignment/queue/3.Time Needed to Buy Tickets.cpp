#include <iostream>
using namespace std;

int timeRequiredToBuy(int tickets[], int n, int k) {
    int time = 0;
    int target = tickets[k];

    for (int i = 0; i < n; i++) {
        if (i <= k)
            time += (tickets[i] < target) ? tickets[i] : target;
        else
            time += (tickets[i] < target - 1) ? tickets[i] : (target - 1);
    }

    return time;
}

int main() {
    const int MAX = 100;
    int tickets[MAX];
    int n, k;

    cout << "Enter number of people: ";
    cin >> n;

    cout << "Enter ticket counts for each person: ";
    for (int i = 0; i < n; i++) {
        cin >> tickets[i];
    }

    cout << "Enter the position k: ";
    cin >> k;

    int result = timeRequiredToBuy(tickets, n, k);
    cout << "Total time for person at position " << k << ": " << result << " seconds" << endl;

    return 0;
}
