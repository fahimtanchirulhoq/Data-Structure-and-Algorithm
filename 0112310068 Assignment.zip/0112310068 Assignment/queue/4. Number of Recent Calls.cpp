#include <iostream>
using namespace std;

class RecentCounter {
private:
    static const int MAX = 10000;  // max calls per constraints
    int requests[MAX];
    int head, tail;

public:
    RecentCounter() {
        head = 0;
        tail = 0;
    }

    int ping(int t) {
        requests[tail++] = t;  // enqueue new request time

        // dequeue requests outside the [t-3000, t] window
        while (requests[head] < t - 3000) {
            head++;
        }

        // number of requests in the window
        return tail - head;
    }
};

int main() {
    RecentCounter recentCounter;

    cout << recentCounter.ping(1) << "\n";      
    cout << recentCounter.ping(100) << "\n";    
    cout << recentCounter.ping(3001) << "\n";   // returns 3
    cout << recentCounter.ping(3002) << "\n";   // returns 3

    return 0;
}
