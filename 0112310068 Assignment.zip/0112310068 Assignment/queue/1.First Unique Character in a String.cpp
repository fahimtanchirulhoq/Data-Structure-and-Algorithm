#include <iostream>
#include <string>
using namespace std;

int firstUniqChar(const string& s) {
    const int CHAR_RANGE = 256;  // for ASCII
    int freq[CHAR_RANGE] = {0};
    int firstIndex[CHAR_RANGE];
    
    // Initialize all indices to -1
    for (int i = 0; i < CHAR_RANGE; i++) {
        firstIndex[i] = -1;
    }

    for (int i = 0; i < (int)s.size(); i++) {
      char c = s[i];
        freq[c]++;
        if (firstIndex[c] == -1) {
            firstIndex[c] = i;
        }
    }

    int result = -1;
    for (int i = 0; i < CHAR_RANGE; i++) {
        if (freq[i] == 1) {
            if (result == -1 || firstIndex[i] < result) {
                result = firstIndex[i];
            }
        }
    }

    return result;
}

int main() {
    string s;
    cout << "Enter the string: ";
    getline(cin, s);

    int index = firstUniqChar(s);
    cout << "First non-repeating character index: " << index << endl;

    return 0;
}
