#include <bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* next;
};

// Insert at end
void insertAtLast(Node* &head, int val) {
    Node* newNode = new Node;
    newNode->data = val;
    newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
        return;
    }

    Node* ptr = head;
    while (ptr->next != NULL) {
        ptr = ptr->next;
    }
    ptr->next = newNode;
}

// Print list
void printList(Node* head) {
    Node* ptr = head;
    while (ptr != NULL) {
        cout << ptr->data;
        if (ptr->next != NULL) cout << "->";
        ptr = ptr->next;
    }
    cout << endl;
}

// Remove nth node from end
Node* removeNthFromEnd(Node* head, int n) {
    Node* dummy = new Node;
    dummy->data = 0;
    dummy->next = head;

    Node* fast = dummy;
    Node* slow = dummy;

    // Move fast n+1 steps ahead
    for (int i = 0; i <= n; i++) {
        if (fast == NULL) return head; // n is too big
        fast = fast->next;
    }

    // Move both until fast reaches end
    while (fast != NULL) {
        fast = fast->next;
        slow = slow->next;
    }

    // Delete slow->next
    Node* toDelete = slow->next;
    slow->next = toDelete->next;
    delete toDelete;

    Node* newHead = dummy->next;
    delete dummy;
    return newHead;
}

int main() {
    Node* head = NULL;
    int n, val, del;

    cout << "Enter number of elements: ";
    cin >> n;
    cout << "Enter elements: ";
    for (int i = 0; i < n; i++) {
        cin >> val;
        insertAtLast(head, val);
    }

    cout << "Enter n (position from end to delete): ";
    cin >> del;

    cout << "Original List: ";
    printList(head);

    head = removeNthFromEnd(head, del);

    cout << "After Removing " << del << "-th node from end: ";
    printList(head);

    return 0;
}
