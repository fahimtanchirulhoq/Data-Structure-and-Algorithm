#include <bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* next;
};


void insertAtLast(Node* &head, int val) {
    Node* n = new Node;
    n->data = val;
    n->next = NULL;

    if (head == NULL) {
        head = n;
        return;
    }

    Node* ptr = head;
    while (ptr->next != NULL) {
        ptr = ptr->next;
    }
    ptr->next = n;
}

// Print list
void printList(Node* head) {
    while (head != NULL) {
        cout << head->data;
        if (head->next != NULL) cout << "->";
        head = head->next;
    }
    cout << endl;
}

// Rotate list right by k positions
Node* rotateRight(Node* head, int k) {
    if (head == NULL || head->next == NULL || k == 0) return head;

    // count length and find last node
    int len = 1;
    Node* tail = head;
    while (tail->next != NULL) {
        tail = tail->next;
        len++;
    }

    //  reduce k 
    k = k % len;
    if (k == 0) return head;

    // make list circular
    tail->next = head;

    // find new tail: move len-k-1 steps from head
    Node* newTail = head;
    for (int i = 0; i < len - k - 1; i++) {
        newTail = newTail->next;
    }

    //  new head is next of new tail
    Node* newHead = newTail->next;

    //  break circle
    newTail->next = NULL;

    return newHead;
}

int main() {
    Node* head = NULL;
    int n, val, k;

    cout << "Enter number of elements: ";
    cin >> n;

    cout << "Enter elements: ";
    for (int i = 0; i < n; i++) {
        cin >> val;
        insertAtLast(head, val);
    }

    cout << "Enter k (rotation steps): ";
    cin >> k;

    cout << "Original List: ";
    printList(head);

    head = rotateRight(head, k);

    cout << "Rotated List: ";
    printList(head);

    return 0;
}
