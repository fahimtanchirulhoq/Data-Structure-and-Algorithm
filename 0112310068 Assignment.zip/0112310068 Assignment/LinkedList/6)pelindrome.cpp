#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node *next;
};

// Insert at end
void insertAtLast(Node* &head, int val) {
    Node* newNode = new Node;
    newNode->data = val;
    newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
        return;
    }

    Node* ptr = head;
    while (ptr->next != NULL) {
        ptr = ptr->next;
    }
    ptr->next = newNode;
}

// Reverse a list
Node* reverse(Node* head) {
    Node* prev = NULL;
    Node* curr = head;
    while (curr != NULL) {
        Node* next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    return prev;
}

// Check if palindrome
bool isPalindrome(Node* head) {
    if (head == NULL || head->next == NULL) return true;

    // Step 1: Find middle
    Node* slow = head;
    Node* fast = head;
    while (fast->next != NULL && fast->next->next != NULL) {
        slow = slow->next;
        fast = fast->next->next;
    }

    // Step 2: Reverse second half
    Node* secondHalf = reverse(slow->next);

    // Step 3: Compare halves
    Node* p1 = head;
    Node* p2 = secondHalf;
    while (p2 != NULL) {
        if (p1->data != p2->data) {
            return false;
        }
        p1 = p1->next;
        p2 = p2->next;
    }

    return true;
}

// Print list
void printList(Node* head) {
    Node* ptr = head;
    while (ptr != NULL) {
        cout << ptr->data << "->";
        ptr = ptr->next;
    }
    cout << "NULL" << endl;
}

int main() {
    Node* head = NULL;
    int n, val;

    cout << "Enter number of elements: ";
    cin >> n;

    cout << "Enter elements: ";
    for (int i = 0; i < n; i++) {
        cin >> val;
        insertAtLast(head, val);
    }

    cout << "Original List: ";
    printList(head);

    if (isPalindrome(head))
        cout << "Output: true (It is a palindrome)" << endl;
    else
        cout << "Output: false (Not a palindrome)" << endl;

    return 0;
}
