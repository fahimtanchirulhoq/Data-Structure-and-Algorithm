#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node *next;
};

void insertAtLast(Node* &head, int val) {
    Node* newNode = new Node;
    newNode->data = val;
    newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
        return;
    }

    Node* ptr = head;
    while (ptr->next != NULL) {
        ptr = ptr->next;
    }
    ptr->next = newNode;
}


void printList(Node* head) {
    cout << "-------Linked List-------" << endl;
    Node* ptr = head;
    while (ptr != NULL) {
        cout << ptr->data << "->";
        ptr = ptr->next;
    }
    cout << "NULL" << endl;
}


Node* removeDuplicates(Node* head) {
    Node* curr = head;
    while (curr != NULL && curr->next != NULL) {
        if (curr->data == curr->next->data) {
            Node* tmp = curr->next;
            curr->next = tmp->next;
            delete tmp;
        } else {
            curr = curr->next;
        }
    }
    return head;
}

int main() {
    Node* head = NULL;

    // Example input: [1,1,2,3,3]
    insertAtLast(head, 1);
    insertAtLast(head, 1);
    insertAtLast(head, 2);
    insertAtLast(head, 3);
    insertAtLast(head, 3);

    cout << "Original List:" << endl;
    printList(head);

    head = removeDuplicates(head);

    cout << "List after removing duplicates:" << endl;
    printList(head);

    return 0;
}
