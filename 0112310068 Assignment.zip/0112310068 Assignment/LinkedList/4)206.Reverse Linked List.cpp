#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node *next;
};

// Insert at end
void insertAtLast(Node* &head, int val) {
    Node* newNode = new Node;
    newNode->data = val;
    newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
        return;
    }

    Node* ptr = head;
    while (ptr->next != NULL) {
        ptr = ptr->next;
    }
    ptr->next = newNode;
}

// Print list
void printList(Node* head) {
    cout << "-------Linked List-------" << endl;
    Node* ptr = head;
    while (ptr != NULL) {
        cout << ptr->data << "->";
        ptr = ptr->next;
    }
    cout << "NULL" << endl;
}

// Reverse the list
Node* reverseList(Node* head) {
    Node* prev = NULL;
    Node* curr = head;
    Node* next = NULL;

    while (curr != NULL) {
        next = curr->next;  // store next
        curr->next = prev;  
        prev = curr;        
        curr = next;       
    }

    return prev; // new head
}

int main() {
    Node* head = NULL;
    int n, val;

    cout << "Enter number of elements: ";
    cin >> n;

    cout << "Enter elements: ";
    for (int i = 0; i < n; i++) {
        cin >> val;
        insertAtLast(head, val);
    }

    cout << "Original List:" << endl;
    printList(head);

    head = reverseList(head);

    cout << "Reversed List:" << endl;
    printList(head);

    return 0;
}
