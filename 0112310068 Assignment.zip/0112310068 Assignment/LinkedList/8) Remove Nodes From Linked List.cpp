#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* next;
};

void insertAtLast(Node* &head, int val) {
    Node* newNode = new Node;
    newNode->data = val;
    newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
        return;
    }

    Node* ptr = head;
    while (ptr->next != NULL) {
        ptr = ptr->next;
    }
    ptr->next = newNode;
}

// Reverse the list
Node* reverse(Node* head) {
    Node* prev = NULL;
    Node* curr = head;
    while (curr != NULL) {
        Node* next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    return prev;
}

// Remove nodes having greater value on the right
Node* removeNodes(Node* head) {
    if (!head || !head->next) return head;

    head = reverse(head); // Step 1: Reverse
    Node* curr = head;
    int maxVal = curr->data;

    while (curr != NULL && curr->next != NULL) {
        if (curr->next->data < maxVal) {
            Node* tmp = curr->next;
            curr->next = tmp->next;
            delete tmp;
        } else {
            curr = curr->next;
            maxVal = curr->data;
        }
    }

    head = reverse(head); // Step 2: Reverse again
    return head;
}

// Print list
void printList(Node* head) {
    Node* ptr = head;
    while (ptr != NULL) {
        cout << ptr->data << "->";
        ptr = ptr->next;
    }
    cout << "NULL" << endl;
}

int main() {
    Node* head = NULL;
    int n, val;

    cout << "Enter number of elements: ";
    cin >> n;

    cout << "Enter elements: ";
    for (int i = 0; i < n; i++) {
        cin >> val;
        insertAtLast(head, val);
    }

    cout << "Original List: ";
    printList(head);

    head = removeNodes(head);

    cout << "Modified List: ";
    printList(head);

    return 0;
}
