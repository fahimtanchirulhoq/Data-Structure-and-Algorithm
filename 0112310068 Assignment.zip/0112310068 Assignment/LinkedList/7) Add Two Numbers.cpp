#include <bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* next;
};

// Insert at end
void insertAtLast(Node* &head, int val) {
    Node* newNode = new Node;
    newNode->data = val;
    newNode->next = NULL;

    if (head == NULL) {
        head = newNode;
        return;
    }

    Node* ptr = head;
    while (ptr->next != NULL) {
        ptr = ptr->next;
    }
    ptr->next = newNode;
}

// Print linked list
void printList(Node* head) {
    Node* ptr = head;
    while (ptr != NULL) {
        cout << ptr->data;
        if (ptr->next != NULL) cout << "->";
        ptr = ptr->next;
    }
    cout << endl;
}

// Add two numbers represented by reverse linked lists
Node* addTwoNumbers(Node* l1, Node* l2) {
    Node* dummy = new Node;
    dummy->data = 0;
    dummy->next = NULL;
    Node* tail = dummy;
    int carry = 0;

    while (l1 != NULL || l2 != NULL || carry > 0) {
        int sum = carry;
        if (l1 != NULL) {
            sum += l1->data;
            l1 = l1->next;
        }
        if (l2 != NULL) {
            sum += l2->data;
            l2 = l2->next;
        }

        Node* newNode = new Node;
        newNode->data = sum % 10;
        newNode->next = NULL;
        tail->next = newNode;
        tail = newNode;

        carry = sum / 10;
    }

    return dummy->next;
}

int main() {
    Node* l1 = NULL;
    Node* l2 = NULL;
    int n1, n2, val;

    // Input for l1
    cout << "Enter number of digits in l1: ";
    cin >> n1;
    cout << "Enter digits for l1 (in reverse order): ";
    for (int i = 0; i < n1; i++) {
        cin >> val;
        insertAtLast(l1, val);
    }

    // Input for l2
    cout << "Enter number of digits in l2: ";
    cin >> n2;
    cout << "Enter digits for l2 (in reverse order): ";
    for (int i = 0; i < n2; i++) {
        cin >> val;
        insertAtLast(l2, val);
    }

    cout << "L1: ";
    printList(l1);
    cout << "L2: ";
    printList(l2);

    Node* result = addTwoNumbers(l1, l2);
    cout << "Sum: ";
    printList(result);

    return 0;
}
