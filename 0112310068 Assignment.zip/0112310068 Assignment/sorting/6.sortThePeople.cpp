#include <iostream>
#include <string>
using namespace std;

int main() {
    const int n = 3;
    string names[n] = {"Mary", "John", "Emma"};
    int heights[n] = {180, 165, 170};

    // Selection sort in descending order by heights
    for (int i = 0; i < n - 1; i++) {
        int maxIdx = i;
        for (int j = i + 1; j < n; j++) {
            if (heights[j] > heights[maxIdx]) {
                maxIdx = j;
            }
        }
        // Swap heights
        int tempH = heights[i];
        heights[i] = heights[maxIdx];
        heights[maxIdx] = tempH;

        // Swap  names
        string tempN = names[i];
        names[i] = names[maxIdx];
        names[maxIdx] = tempN;
    }

    // Output sorted names
    for (int i = 0; i < n; i++) {
        cout << names[i];
        if (i < n - 1) cout << ", ";
    }
    cout << endl;

    return 0;
}
