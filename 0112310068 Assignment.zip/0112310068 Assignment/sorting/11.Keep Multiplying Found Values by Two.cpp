#include <iostream>
using namespace std;

bool found(int arr[], int n, int x) {
    for (int i = 0; i < n; i++) {
        if (arr[i] == x) return true;
    }
    return false;
}

int main() {
    int nums[] = {5, 3, 6, 1, 12};
    int n = sizeof(nums) / sizeof(nums[0]);
    int original = 3;

    while (found(nums, n, original)) {
        original = original * 2;
    }

    cout << "Final value: " << original << endl;

    return 0;
}
