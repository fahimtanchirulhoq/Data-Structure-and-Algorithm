#include <iostream>
using namespace std;

int main() {
    char s[105];
    cin >> s;

    char digits[55]; 
    int k = 0;

 
    for (int i = 0; s[i] != '\0'; i++) {
        if (s[i] != '+') {
            digits[k++] = s[i];
        }
    }

    // Simple bubble sort
    for (int i = 0; i < k - 1; i++) {
        for (int j = 0; j < k - 1 - i; j++) {
            if (digits[j] > digits[j + 1]) {
                char temp = digits[j];
                digits[j] = digits[j + 1];
                digits[j + 1] = temp;
            }
        }
    }

    // Print the result
    for (int i = 0; i < k; i++) {
        cout << digits[i];
        if (i != k - 1) {
            cout << '+';
        }
    }

    return 0;
}
