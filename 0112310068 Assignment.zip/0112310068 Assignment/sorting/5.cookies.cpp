#include <iostream>
using namespace std;


void sortArray(int arr[], int n) {
    for (int i = 0; i < n-1; i++) {
        int minIdx = i;
        for (int j = i+1; j < n; j++) {
            if (arr[j] < arr[minIdx])
                minIdx = j;
        }
        int temp = arr[i];
        arr[i] = arr[minIdx];
        arr[minIdx] = temp;
    }
}

int main() {
    int g[] = {1, 2, 3}; // greed factors
    int s[] = {1, 1};    // cookie sizes
    int n = sizeof(g)/sizeof(g[0]);
    int m = sizeof(s)/sizeof(s[0]);

    // Sort both arrays
    sortArray(g, n);
    sortArray(s, m);

    int i = 0, j = 0, count = 0;

    // Assign cookies 
    while (i < n && j < m) {
        if (s[j] >= g[i]) {
            count++;
            i++;
            j++;
        } else {
            j++;
        }
    }

    cout << "Maximum number of content children: " << count << endl;
    return 0;
}
