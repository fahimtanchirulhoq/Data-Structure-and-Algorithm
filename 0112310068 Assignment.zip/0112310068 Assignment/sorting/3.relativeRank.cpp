#include <iostream>
using namespace std;

int main() {
    int prices[] = {3, 2, 3}; // Change input here
    int money = 3;
    int n = sizeof(prices) / sizeof(prices[0]);

    int minCost = 1000000;

    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            int sum = prices[i] + prices[j];
            if (sum <= money && sum < minCost) {
                minCost = sum;
            }
        }
    }

    if (minCost ==1000000 ) {
        cout << money << endl;
    } else {
        cout << (money - minCost) << endl;
    }

    return 0;
}
