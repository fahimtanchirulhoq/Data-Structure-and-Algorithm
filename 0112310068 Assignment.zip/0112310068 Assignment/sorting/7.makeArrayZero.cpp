#include <iostream>
using namespace std;

int main() {
    int nums[] = {1, 5, 0, 3, 5};
    int n = sizeof(nums) / sizeof(nums[0]);

   
    int maxVal = 0;
    for (int i = 0; i < n; i++) {
        if (nums[i] > maxVal) maxVal = nums[i];
    }

    // Use a boolean array to mark which positive numbers exist
    bool seen[maxVal + 1];
    for (int i = 0; i <= maxVal; i++) {
        seen[i] = false;
    }

    // Mark all positive numbers
    for (int i = 0; i < n; i++) {
        if (nums[i] > 0) {
            seen[nums[i]] = true;
        }
    }

    // Count distinct positive numbers
    int count = 0;
    for (int i = 1; i <= maxVal; i++) {
        if (seen[i]) count++;
    }

    cout << "Minimum operations: " << count << endl;

    return 0;
}
