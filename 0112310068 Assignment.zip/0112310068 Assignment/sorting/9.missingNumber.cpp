#include <iostream>
using namespace std;

int main() {
    int nums[] = {3, 0, 1};
    int n = sizeof(nums) / sizeof(nums[0]);

    int total = n * (n + 1) / 2;
    int sum = 0;

    for (int i = 0; i < n; i++) {
        sum += nums[i];
    }

    int missing = total - sum;
    cout << "Missing number is: " << missing << endl;

    return 0;
}
