#include <iostream>
using namespace std;

bool isAnagram(const char* s, const char* t) {
    int count[26] = {0};

    // Calculate lengths
    int len_s = 0, len_t = 0;
    while (s[len_s] != '\0') len_s++;
    while (t[len_t] != '\0') len_t++;
    if (len_s != len_t) return false;

    // Count chars
    for (int i = 0; i < len_s; i++) {
        count[s[i] - 'a']++;
        count[t[i] - 'a']--;
    }

    // Check counts
    for (int i = 0; i < 26; i++) {
        if (count[i] != 0) return false;
    }
    return true;
}

int main() {
    const char* s = "anagram";
    const char* t = "nagaram";

    if (isAnagram(s, t))
        cout << "true\n";
    else
        cout << "false\n";

    return 0;
}
