#include <iostream>
using namespace std;

int main() {
    int n;
    cin >> n;

    int scores[1001][4];
    int sum[1001];

  
    for (int i = 1; i <= n; i++) {
        int total = 0;
        for (int j = 0; j < 4; j++) {
            cin >> scores[i][j];
            total += scores[i][j];
        }
        sum[i] = total;
    }

    int thomasSum = sum[1];
    int rank = 1;

    for (int i = 2; i <= n; i++) {
        
        if (sum[i] > thomasSum) {
            rank++;
        }
    }

    cout << rank << "\n";

    return 0;
}
