#include <iostream>
using namespace std;

void sortDescending(int arr[], int n) {
    
    for (int i = 0; i < n - 1; i++) {
        int maxIdx = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] > arr[maxIdx])
                maxIdx = j;
        }
        int temp = arr[i];
        arr[i] = arr[maxIdx];
        arr[maxIdx] = temp;
    }
}

int main() {
    int num = 65875;
    int digits[20]; 
    int n = 0;

    int temp = num;
    
    while (temp > 0) {
        digits[n++] = temp % 10;
        temp /= 10;
    }

    for (int i = 0; i < n / 2; i++) {
        int t = digits[i];
        digits[i] = digits[n - i - 1];
        digits[n - i - 1] = t;
    }

    int even[20], odd[20];
    int evenCount = 0, oddCount = 0;

  
    for (int i = 0; i < n; i++) {
        if (digits[i] % 2 == 0)
            even[evenCount++] = digits[i];
        else
            odd[oddCount++] = digits[i];
    }


    sortDescending(even, evenCount);
    sortDescending(odd, oddCount);

    int evenIdx = 0, oddIdx = 0;

    for (int i = 0; i < n; i++) {
        if (digits[i] % 2 == 0)
            digits[i] = even[evenIdx++];
        else
            digits[i] = odd[oddIdx++];
    }

    for (int i = 0; i < n; i++) {
        cout << digits[i];
    }
    cout << endl;

    return 0;
}
