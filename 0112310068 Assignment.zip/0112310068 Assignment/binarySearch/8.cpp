#include <iostream>
using namespace std;

int maxCountPositiveNegative(int nums[], int n) {
    // Binary search for first positive
    int low = 0, high = n - 1;
    int firstPos = n; // default if no positive numbers

    while (low <= high) {
        int mid = (low + high) / 2;
        if (nums[mid] > 0) {
            firstPos = mid;
            high = mid - 1;
        } else {
            low = mid + 1;
        }
    }

    // Binary search for last negative
    low = 0, high = n - 1;
    int lastNeg = -1; // default if no negative numbers

    while (low <= high) {
        int mid = (low + high) / 2;
        if (nums[mid] < 0) {
            lastNeg = mid;
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }

    int posCount = n - firstPos;
    int negCount = lastNeg + 1;

    return (posCount > negCount) ? posCount : negCount;
}

int main() {
    int nums1[] = {-2, -1, -1, 1, 2, 3};
    cout << maxCountPositiveNegative(nums1, 6) << endl;  // Output: 3

    int nums2[] = {-3, -2, -1, 0, 0, 1, 2};
    cout << maxCountPositiveNegative(nums2, 7) << endl;  // Output: 3

    int nums3[] = {5, 20, 66, 1314};
    cout << maxCountPositiveNegative(nums3, 4) << endl;  // Output: 4

    return 0;
}
