#include <iostream>
using namespace std;

bool canEatAll(int piles[], int n, int h, int k) {
    int time = 0;
    for (int i = 0; i < n; i++) {
        
        time += (piles[i] + k - 1) / k;
        if (time > h) return false;
    }
    return true;
}

int minEatingSpeed(int piles[], int n, int h) {
    int left = 1;
    int right = 0;


    for (int i = 0; i < n; i++) {
        if (piles[i] > right)
            right = piles[i];
    }

    int result = right;

    while (left <= right) {
        int mid = (left + right) / 2;

        if (canEatAll(piles, n, h, mid)) {
            result = mid;       
            right = mid - 1;
        } else {
            left = mid + 1;     
        }
    }

    return result;
}

int main() {
    int piles1[] = {3, 6, 7, 11};
    int h1 = 8;
    cout << "Minimum k: " << minEatingSpeed(piles1, 4, h1) << endl;  // Output: 4

    int piles2[] = {30, 11, 23, 4, 20};
    int h2 = 5;
    cout << "Minimum k: " << minEatingSpeed(piles2, 5, h2) << endl;  // Output: 30

    int h3 = 6;
    cout << "Minimum k: " << minEatingSpeed(piles2, 5, h3) << endl;  // Output: 23

    return 0;
}
