#include <iostream>
using namespace std;

int main() {
    int n, money;
    cout << "Enter number of chocolates: ";
    cin >> n;

    int prices[100];  // assuming max 100 chocolates
    cout << "Enter prices: ";
    for (int i = 0; i < n; i++) {
        cin >> prices[i];
    }

    cout << "Enter money you have: ";
    cin >> money;

    int min1 = 101, min2 = 101;  // prices are in range 1–100

    // Find the two smallest prices
    for (int i = 0; i < n; i++) {
        if (prices[i] < min1) {
            min2 = min1;
            min1 = prices[i];
        } else if (prices[i] < min2) {
            min2 = prices[i];
        }
    }

    int total = min1 + min2;

    if (total <= money)
        cout << "Remaining money: " << money - total << endl;
    else
        cout << "Not enough money. Remaining: " << money << endl;

    return 0;
}
