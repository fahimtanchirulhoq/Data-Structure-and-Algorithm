#include <iostream>
using namespace std;

int mySqrt(int x) {
    if (x == 0 || x == 1)
        return x;

    int left = 1, right = x, ans = 0;

    while (left <= right) {
        int mid = left + (right - left) / 2;

        
        if (mid <= x / mid) {
            ans = mid;           
            left = mid + 1;
        } else {
            right = mid - 1;    
        }
    }

    return ans;
}

int main() {
    int x1 = 4;
    cout << "sqrt(" << x1 << ") = " << mySqrt(x1) << endl;  // Output: 2

    int x2 = 8;
    cout << "sqrt(" << x2 << ") = " << mySqrt(x2) << endl;  // Output: 2

    int x3 = 0;
    cout << "sqrt(" << x3 << ") = " << mySqrt(x3) << endl;  // Output: 0

    int x4 = 2147395599;
    cout << "sqrt(" << x4 << ") = " << mySqrt(x4) << endl;  // Output: 46339

    return 0;
}
