#include <iostream>
using namespace std;

int main() {
    string s;
    cin >> s;


    int count1 = 0, count2 = 0, count3 = 0;

    for (int i = 0; i < s.length(); i += 2) {
        if (s[i] == '1') count1++;
        else if (s[i] == '2') count2++;
        else if (s[i] == '3') count3++;
    }

 
    bool first = true;
    while (count1--) {
        if (!first) cout << "+";
        cout << "1";
        first = false;
    }
    while (count2--) {
        if (!first) cout << "+";
        cout << "2";
        first = false;
    }
    while (count3--) {
        if (!first) cout << "+";
        cout << "3";
        first = false;
    }

    cout << endl;
    return 0;
}
