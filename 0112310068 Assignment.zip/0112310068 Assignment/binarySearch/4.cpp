#include <iostream>
using namespace std;

int findPeakElement(int nums[], int n) {
    int left = 0, right = n - 1;

    while (left < right) {
        int mid = (left + right) / 2;

        if (nums[mid] > nums[mid + 1]) {
            
            right = mid;
        } else {
            
            left = mid + 1;
        }
    }

   
    return left;
}

int main() {
    int nums1[] = {1, 2, 3, 1};
    int n1 = sizeof(nums1) / sizeof(nums1[0]);
    cout << "Peak index: " << findPeakElement(nums1, n1) << endl;  // Output: 2

    int nums2[] = {1, 2, 1, 3, 5, 6, 4};
    int n2 = sizeof(nums2) / sizeof(nums2[0]);
    cout << "Peak index: " << findPeakElement(nums2, n2) << endl;  // Output: 5 or 1

    return 0;
}
