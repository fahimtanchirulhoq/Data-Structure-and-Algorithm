#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Student {
    int id;
    int totalScore;
};

bool compare(const Student& a, const Student& b) {
    if (a.totalScore != b.totalScore)
        return a.totalScore > b.totalScore; 
    return a.id < b.id; 
}

int main() {
    int n;
    cin >> n;

    vector<Student> students(n);

    for (int i = 0; i < n; i++) {
        int a, b, c, d;
        cin >> a >> b >> c >> d;
        students[i].id = i + 1;
        students[i].totalScore = a + b + c + d;
    }

    sort(students.begin(), students.end(), compare);

    for (int rank = 0; rank < n; rank++) {
        if (students[rank].id == 1) {
            cout << rank + 1 << endl; // Rank is 1-based
            break;
        }
    }

    return 0;
}
