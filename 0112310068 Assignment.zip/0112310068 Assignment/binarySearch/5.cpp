#include <iostream>
using namespace std;

int findMin(int nums[], int n) {
    int left = 0, right = n - 1;

    while (left < right) {
        int mid = (left + right) / 2;

    
        if (nums[mid] > nums[right]) {
            left = mid + 1;
        } else {
            
            right = mid;
        }
    }

    // At the end of loop, left == right is the index of the minimum
    return nums[left];
}

int main() {
    int nums1[] = {3, 4, 5, 1, 2};
    int n1 = sizeof(nums1) / sizeof(nums1[0]);
    cout << "Minimum: " << findMin(nums1, n1) << endl;  // Output: 1

    int nums2[] = {4, 5, 6, 7, 0, 1, 2};
    int n2 = sizeof(nums2) / sizeof(nums2[0]);
    cout << "Minimum: " << findMin(nums2, n2) << endl;  // Output: 0

    int nums3[] = {11, 13, 15, 17};
    int n3 = sizeof(nums3) / sizeof(nums3[0]);
    cout << "Minimum: " << findMin(nums3, n3) << endl;  // Output: 11

    return 0;
}
