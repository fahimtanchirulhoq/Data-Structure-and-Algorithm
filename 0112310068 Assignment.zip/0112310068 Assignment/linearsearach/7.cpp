#include <iostream>
#include <vector>
using namespace std;


int countDigits(int num) {
    int digits = 0;
    while (num != 0) {
        num /= 10;
        digits++;
    }
    return digits;
}

int findNumbersWithEvenDigits(const vector<int>& nums) {
    int count = 0;
    for (int num : nums) {
        if (countDigits(num) % 2 == 0) {
            count++;
        }
    }
    return count;
}

int main() {
    vector<int> nums1 = {12, 345, 2, 6, 7896};
    cout << findNumbersWithEvenDigits(nums1) << endl;  // Output: 2

    vector<int> nums2 = {555, 901, 482, 1771};
    cout << findNumbersWithEvenDigits(nums2) << endl;  // Output: 1

    return 0;
}
