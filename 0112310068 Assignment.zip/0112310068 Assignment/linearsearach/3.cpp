#include <iostream>
using namespace std;


bool hasDistinctDigits(int year) {
    int digitCount[10] = {0};

    while (year > 0) {
        int digit = year % 10;
        if (digitCount[digit] > 0)
            return false; 
        digitCount[digit]++;
        year /= 10;
    }

    return true;
}

int main() {
    int y;
    cin >> y;

    while (true) {
        y++;
        if (hasDistinctDigits(y)) {
            cout << y << endl;
            break;
        }
    }

    return 0;
}
