#include<bits/stdc++.h>
using namespace std;

struct Node {
    int val;
    Node *left, *right;
};

Node* insert(Node *root, int v) {
    if(root == NULL) {
        Node *n = new Node;
        n->val = v;
        n->left = n->right = NULL;
        return n;
    }
    if(v <= root->val) {
        root->left = insert(root->left, v);
    }
    else {
        root->right = insert(root->right, v);
    }
    return root;
}

int curr = -1e6, cnt = 0, mx = 0;
int ans[10000], k = 0;

void inorder(Node *root) {
    if(root == NULL) return;

    inorder(root->left);

    if(root->val == curr) {
        cnt++;
    }
    else {
        curr = root->val;
        cnt = 1;
    }

    if(cnt > mx) {
        mx = cnt;
        k = 0;
        ans[k++] = root->val;
    }
    else if(cnt == mx) {
        ans[k++] = root->val;
    }

    inorder(root->right);
}

int main() {
    Node *root = NULL;
    root = insert(root, 1);
    root = insert(root, 2);
    root = insert(root, 2);

    inorder(root);

    for(int i = 0; i < k; i++) {
        cout << ans[i] << " ";
    }
    cout << endl;
}
