#include<bits/stdc++.h>
using namespace std;

struct Node {
    int val;
    Node *left, *right;
};

Node* insert(Node *root, int v) {
    if(root == NULL) {
        Node *n = new Node;
        n->val = v;
        n->left = n->right = NULL;
        return n;
    }
    if(v <= root->val) {
        root->left = insert(root->left, v);
    }
    else {
        root->right = insert(root->right, v);
    }
    return root;
}

Node* searchBST(Node* root, int val) {
    if(root == NULL) return NULL;
    if(root->val == val) return root;
    else if(val < root->val) return searchBST(root->left, val);
    else return searchBST(root->right, val);
}

// For printing subtree inorder (to show output)
void inorder(Node* root) {
    if(root == NULL) return;
    cout << root->val << " ";
    inorder(root->left);
    inorder(root->right);
}

int main() {
    Node* root = NULL;
    int n, v, val;
    cin >> n;
    for(int i=0; i<n; i++) {
        cin >> v;
        root = insert(root, v);
    }
    cin >> val;

    Node* res = searchBST(root, val);
    if(res == NULL) {
        cout << endl; // empty output for no node found
    } else {
        inorder(res);
        cout << endl;
    }

    return 0;
}
