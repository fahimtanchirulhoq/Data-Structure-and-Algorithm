
#include<bits/stdc++.h>
using namespace std;

struct Node {
    int val;
    Node *left, *right;
};

Node* insert(Node *root, int v) {
    if(root == NULL) {
        Node *n = new Node;
        n->val = v;
        n->left = n->right = NULL;
        return n;
    }
    if(v <= root->val) {
        root->left = insert(root->left, v);
    }
    else {
        root->right = insert(root->right, v);
    }
    return root;
}

int rangeSumBST(Node *root, int low, int high) {
    if(root == NULL) return 0;

    if(root->val < low) {
        // Current node value too small, skip left subtree
        return rangeSumBST(root->right, low, high);
    }
    else if(root->val > high) {
        // Current node value too big, skip right subtree
        return rangeSumBST(root->left, low, high);
    }
    else {
        // Current node in range, add it and explore both sides
        return root->val + rangeSumBST(root->left, low, high) + rangeSumBST(root->right, low, high);
    }
}

int main() {
    Node *root = NULL;
    int n, v, low, high;
    cin >> n;
    for(int i = 0; i < n; i++) {
        cin >> v;
        root = insert(root, v);
    }
    cin >> low >> high;

    cout << rangeSumBST(root, low, high) << endl;

    return 0;
}
