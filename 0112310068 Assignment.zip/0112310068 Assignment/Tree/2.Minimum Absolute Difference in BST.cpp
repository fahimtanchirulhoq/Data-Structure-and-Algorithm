#include<bits/stdc++.h>
using namespace std;

struct Node {
    int val;
    Node *left, *right;
};

Node* insert(Node *root, int v) {
    if(root == NULL) {
        Node *n = new Node;
        n->val = v;
        n->left = n->right = NULL;
        return n;
    }
    if(v <= root->val) {
        root->left = insert(root->left, v);
    }
    else {
        root->right = insert(root->right, v);
    }
    return root;
}

int prevVal = -1e7; // sentinel value for first node
int minDiff = 1e9;

void inorder(Node *root) {
    if(root == NULL) return;

    inorder(root->left);

    if(prevVal != -1e7) {
        int diff = root->val - prevVal;
        if(diff < minDiff) {
            minDiff = diff;
        }
    }
    prevVal = root->val;

    inorder(root->right);
}

int main() {
    Node *root = NULL;
    int n, v;

    // Read number of nodes
    cin >> n;

    // Insert values into BST
    for(int i = 0; i < n; i++) {
        cin >> v;
        root = insert(root, v);
    }

    inorder(root);

    cout << minDiff << endl;

    return 0;
}
